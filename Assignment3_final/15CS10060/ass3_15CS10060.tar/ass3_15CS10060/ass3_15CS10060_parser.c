#include "y.tab.c"
extern int yyparse();
int main()
{
	int x;
	yyparse();
	
}
